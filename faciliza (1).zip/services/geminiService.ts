
import { GoogleGenAI, Type } from "@google/genai";

export const parseAICommand = async (command: string, currentContext: any) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Comando: "${command}"\n\nContexto: ${JSON.stringify(currentContext)}`,
    config: {
      systemInstruction: `Você é um assistente de gestão empresarial. 
      Transforme comandos em ações JSON.
      
      Ações:
      1. ADD_PRODUCT: { "name": string, "costPrice": number, "salePrice": number, "stockQuantity": number }
      2. UPDATE_STOCK: { "productId": string, "quantityChange": number }
      3. ADD_CONTACT: { "name": string, "type": "customer" | "supplier" | "employee", "phone": string }
      4. ERROR: { "message": string }
      
      Retorne APENAS o JSON.`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          action: { type: Type.STRING, enum: ["ADD_PRODUCT", "UPDATE_STOCK", "ADD_CONTACT", "ERROR"] },
          data: { type: Type.OBJECT, properties: {
            name: { type: Type.STRING },
            costPrice: { type: Type.NUMBER },
            salePrice: { type: Type.NUMBER },
            stockQuantity: { type: Type.NUMBER },
            productId: { type: Type.STRING },
            quantityChange: { type: Type.NUMBER },
            type: { type: Type.STRING },
            phone: { type: Type.STRING },
            message: { type: Type.STRING }
          }}
        },
        required: ["action", "data"]
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    return { action: "ERROR", data: { message: "Não consegui processar seu comando." } };
  }
};

export const parseFinancialVoice = async (transcript: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Fala do usuário: "${transcript}"`,
    config: {
      systemInstruction: `Você é um extrator de dados financeiros. 
      Sua tarefa é ouvir o que o usuário recebeu em cada modalidade de pagamento e o que gastou.
      Ignore palavras irrelevantes. Se ele disser "recebi cinquenta no pix e dez no dinheiro", mapeie pix: 50, cash: 10.
      
      Mapeamento:
      - credit (cartão de crédito)
      - debit (cartão de débito)
      - pix (transferência pix)
      - cash (dinheiro físico)
      - expenses (despesas/gastos citados)
      
      Retorne APENAS o JSON puro. Valores que não forem citados devem ser 0.`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          credit: { type: Type.NUMBER },
          debit: { type: Type.NUMBER },
          pix: { type: Type.NUMBER },
          cash: { type: Type.NUMBER },
          expenses: { type: Type.NUMBER }
        },
        required: ["credit", "debit", "pix", "cash", "expenses"]
      }
    }
  });

  try {
    const text = response.text || "{}";
    return JSON.parse(text);
  } catch (e) {
    console.error("Erro ao processar JSON da IA:", e);
    return null;
  }
};

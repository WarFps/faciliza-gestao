
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { RemoteSalePoint, RemoteSaleSession, Product, RemoteSaleItem, RemoteExpense, AppTab } from '../types';
import { parseFinancialVoice } from '../services/geminiService';

interface RemoteSalesProps {
  points: RemoteSalePoint[];
  products: Product[];
  addPoint: (name: string) => void;
  updatePoint: (point: RemoteSalePoint) => void;
  updateStock: (productId: string, qty: number, type: 'sale' | 'stock_in' | 'stock_out', entityId?: string, isPaid?: boolean, source?: 'direct' | 'remote', locationName?: string, staffNames?: string) => void;
  canViewProfit: boolean;
  setActiveTab: (tab: AppTab) => void;
}

const RemoteSales: React.FC<RemoteSalesProps> = ({ points, products, addPoint, updatePoint, updateStock, canViewProfit, setActiveTab }) => {
  const [showAddPointModal, setShowAddPointModal] = useState(false);
  const [newPointName, setNewPointName] = useState('');
  
  const [activeSessionPoint, setActiveSessionPoint] = useState<RemoteSalePoint | null>(null);
  const [showOpenSessionModal, setShowOpenSessionModal] = useState(false);
  const [showCloseSessionModal, setShowCloseSessionModal] = useState(false);
  const [viewingHistoryPoint, setViewingHistoryPoint] = useState<RemoteSalePoint | null>(null);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'day' | 'week' | 'month'>('all');

  // Voice IA State
  const [isListening, setIsListening] = useState(false);
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Local state for the "Open Session" modal
  const [sessionStaff, setSessionStaff] = useState('');
  const [localQuantities, setLocalQuantities] = useState<Record<string, number>>({});

  // Closing session state
  const [closingSession, setClosingSession] = useState<RemoteSaleSession | null>(null);
  const [closingPayments, setClosingPayments] = useState({ credit: 0, debit: 0, pix: 0, cash: 0 });
  
  // Detalhamento de despesas no fechamento
  const [closingExpensesList, setClosingExpensesList] = useState<RemoteExpense[]>([]);
  const [newExpenseDesc, setNewExpenseDesc] = useState('');
  const [newExpenseVal, setNewExpenseVal] = useState(0);

  // Refs to handle closures in voice recognition
  const paymentsRef = useRef(closingPayments);
  const expensesRef = useRef(closingExpensesList);

  useEffect(() => {
    paymentsRef.current = closingPayments;
  }, [closingPayments]);

  useEffect(() => {
    expensesRef.current = closingExpensesList;
  }, [closingExpensesList]);

  // Overdue logic
  const overduePoints = useMemo(() => {
    const now = new Date().getTime();
    const dayInMs = 24 * 60 * 60 * 1000;
    return points.filter(p => {
      const activeSession = p.sessions.find(s => s.status === 'open');
      if (!activeSession) return false;
      return (now - new Date(activeSession.date).getTime()) > dayInMs;
    });
  }, [points]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'pt-BR';
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;

      recognitionRef.current.onresult = async (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleVoiceAnalysis(transcript);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        setIsListening(false);
      };
    }
  }, []); 

  const handleVoiceAnalysis = async (transcript: string) => {
    setIsProcessingVoice(true);
    try {
      const result = await parseFinancialVoice(transcript);
      if (result) {
        setClosingPayments(prev => ({
          credit: result.credit || prev.credit,
          debit: result.debit || prev.debit,
          pix: result.pix || prev.pix,
          cash: result.cash || prev.cash
        }));
        
        if (result.expenses > 0) {
          setClosingExpensesList(prev => [...prev, { description: 'Gasto Citado (IA)', value: result.expenses }]);
        }
      }
    } catch (error) {
      console.error("Erro na análise de voz:", error);
    } finally {
      setIsProcessingVoice(false);
    }
  };

  const toggleVoiceCapture = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setIsListening(true);
      try {
        recognitionRef.current?.start();
      } catch (e) {
        console.error("Erro ao iniciar captura:", e);
        setIsListening(false);
      }
    }
  };

  const handleAddPoint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPointName.trim()) return;
    addPoint(newPointName);
    setNewPointName('');
    setShowAddPointModal(false);
  };

  const openSession = (point: RemoteSalePoint) => {
    setActiveSessionPoint(point);
    setSessionStaff('');
    setLocalQuantities({}); 
    setShowOpenSessionModal(true);
  };

  const updateLocalQty = (productId: string, qty: number) => {
    setLocalQuantities(prev => ({
      ...prev,
      [productId]: qty
    }));
  };

  const handleFinalOpen = () => {
    if (!activeSessionPoint || !sessionStaff) return;
    
    const sessionItems: RemoteSaleItem[] = (Object.entries(localQuantities) as [string, number][])
      .filter(([_, qty]) => qty > 0)
      .map(([productId, qty]) => {
        const product = products.find(p => p.id === productId);
        return {
          productId,
          name: product?.name || 'Produto Removido',
          costPrice: product?.costPrice || 0,
          salePrice: product?.salePrice || 0,
          quantityTaken: qty,
          quantitySold: 0
        };
      });

    if (sessionItems.length === 0) {
      alert("Por favor, adicione pelo menos uma mercadoria para levar.");
      return;
    }

    const newSession: RemoteSaleSession = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      staffNames: sessionStaff,
      status: 'open',
      items: sessionItems,
      payments: { credit: 0, debit: 0, pix: 0, cash: 0 },
      expenses: 0,
      expenseList: [],
      notes: ''
    };

    // Remove do estoque geral para levar ao ponto remoto
    sessionItems.forEach(item => {
      updateStock(item.productId, -item.quantityTaken, 'stock_out', undefined, true, 'remote', activeSessionPoint.name, sessionStaff);
    });

    const updatedPoint = { ...activeSessionPoint, sessions: [...activeSessionPoint.sessions, newSession] };
    updatePoint(updatedPoint);
    setShowOpenSessionModal(false);
    setActiveSessionPoint(null);
  };

  const handleAddExpense = () => {
    if (!newExpenseDesc || newExpenseVal <= 0) return;
    setClosingExpensesList([...closingExpensesList, { description: newExpenseDesc, value: newExpenseVal }]);
    setNewExpenseDesc('');
    setNewExpenseVal(0);
  };

  const handleRemoveExpense = (idx: number) => {
    setClosingExpensesList(closingExpensesList.filter((_, i) => i !== idx));
  };

  const handleFinalClose = () => {
    if (!activeSessionPoint || !closingSession) return;

    // 1. Devolver o que não foi vendido ao estoque geral
    closingSession.items.forEach(item => {
      const leftover = item.quantityTaken - item.quantitySold;
      if (leftover > 0) {
        updateStock(item.productId, leftover, 'stock_in', undefined, true, 'remote', activeSessionPoint.name, closingSession.staffNames);
      }
      
      // 2. Registrar as vendas reais no histórico financeiro global
      if (item.quantitySold > 0) {
        updateStock(
          item.productId, 
          item.quantitySold, 
          'sale', 
          undefined, 
          true, 
          'remote', 
          activeSessionPoint.name, 
          closingSession.staffNames
        );
      }
    });

    const totalExpenses = closingExpensesList.reduce((acc, e) => acc + e.value, 0);

    const updatedSession: RemoteSaleSession = {
      ...closingSession,
      status: 'closed',
      payments: closingPayments,
      expenses: totalExpenses,
      expenseList: closingExpensesList
    };

    const updatedSessions = activeSessionPoint.sessions.map(s => s.id === closingSession.id ? updatedSession : s);
    updatePoint({ ...activeSessionPoint, sessions: updatedSessions });
    setShowCloseSessionModal(false);
    setActiveSessionPoint(null);
    setClosingSession(null);
    setClosingExpensesList([]);
  };

  const calculateProfit = (session: RemoteSaleSession, payments: any, expenseList: RemoteExpense[]) => {
    const revenue = (Object.values(payments) as number[]).reduce((a, b) => a + b, 0);
    const cost = session.items.reduce((acc, item) => acc + (item.quantitySold * item.costPrice), 0);
    const totalExpenses = expenseList.reduce((acc, e) => acc + e.value, 0);
    return revenue - cost - totalExpenses;
  };

  const expectedRevenue = useMemo(() => {
    if (!closingSession) return 0;
    return closingSession.items.reduce((acc, item) => acc + (item.quantitySold * item.salePrice), 0);
  }, [closingSession]);

  const totalInformed = useMemo(() => {
    return (Object.values(closingPayments) as number[]).reduce((a, b) => a + b, 0);
  }, [closingPayments]);

  const totalExpensesSum = useMemo(() => {
    return closingExpensesList.reduce((acc, e) => acc + e.value, 0);
  }, [closingExpensesList]);

  const difference = totalInformed - expectedRevenue;

  const filteredHistory = useMemo(() => {
    if (!viewingHistoryPoint) return [];
    const sessions = viewingHistoryPoint.sessions.filter(s => s.status === 'closed');
    if (historyFilter === 'all') return sessions;
    
    const now = new Date();
    return sessions.filter(s => {
      const sDate = new Date(s.date);
      if (historyFilter === 'day') return sDate.toDateString() === now.toDateString();
      if (historyFilter === 'week') {
        const weekAgo = new Date();
        weekAgo.setDate(now.getDate() - 7);
        return sDate >= weekAgo;
      }
      if (historyFilter === 'month') return sDate.getMonth() === now.getMonth() && sDate.getFullYear() === now.getFullYear();
      return true;
    });
  }, [viewingHistoryPoint, historyFilter]);

  return (
    <div className="space-y-8">
      {/* Overdue Notification Banner */}
      {overduePoints.length > 0 && (
        <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-2xl flex items-center gap-4 animate-in slide-in-from-top duration-500 shadow-sm">
          <div className="text-2xl">⚠️</div>
          <div className="flex-1">
            <h4 className="text-sm font-black text-amber-800 uppercase tracking-widest">Fechamento Pendente Necessário</h4>
            <p className="text-xs text-amber-700">Há caixas abertos há mais de 24 horas em: <strong>{overduePoints.map(p => p.name).join(', ')}</strong>. Por favor, encerre as atividades para consolidar o financeiro.</p>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-bold">Pontos de Vendas Remotas</h3>
          <p className="text-sm text-slate-500">Gerencie carrinhos, quiosques e eventos externos.</p>
        </div>
        <button 
          onClick={() => setShowAddPointModal(true)}
          className="bg-indigo-600 text-white px-6 py-3 rounded-2xl text-sm font-bold hover:bg-indigo-700 shadow-xl shadow-indigo-200 transition-all active:scale-95"
        >
          + Novo Ponto de Venda
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {points.map(point => {
          const activeSession = point.sessions.find(s => s.status === 'open');
          const hasClosedSessions = point.sessions.some(s => s.status === 'closed');
          const isOverdue = overduePoints.some(p => p.id === point.id);

          return (
            <div 
              key={point.id} 
              className={`bg-white p-6 rounded-3xl shadow-sm border transition-all flex flex-col ${
                isOverdue ? 'border-amber-300 ring-2 ring-amber-100 shadow-md' : 'border-slate-100 hover:shadow-md'
              }`}
            >
              <div className="flex justify-between items-start mb-6">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-inner ${activeSession ? (isOverdue ? 'bg-amber-50 text-amber-500' : 'bg-indigo-50 text-indigo-500') : 'bg-slate-100 text-slate-400'}`}>
                  {isOverdue ? '⚠️' : '📡'}
                </div>
                <div className="flex gap-2">
                  {hasClosedSessions && (
                    <button 
                      onClick={() => setViewingHistoryPoint(point)}
                      className="px-3 py-1 bg-slate-100 text-slate-500 text-[10px] font-bold rounded-full hover:bg-slate-200 transition-colors uppercase"
                    >
                      Histórico
                    </button>
                  )}
                  {activeSession ? (
                    <span className={`px-3 py-1 text-[10px] font-bold rounded-full animate-pulse uppercase ${isOverdue ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-600'}`}>
                      {isOverdue ? 'Pendente +24h' : 'Caixa Aberto'}
                    </span>
                  ) : (
                    <span className="px-3 py-1 bg-slate-100 text-slate-400 text-[10px] font-bold rounded-full uppercase">Indisponível</span>
                  )}
                </div>
              </div>

              <h4 className="text-xl font-bold mb-2">{point.name}</h4>
              
              <div className="mt-auto pt-4">
                {activeSession ? (
                  <div className="space-y-4">
                    <div className={`p-4 rounded-2xl border ${isOverdue ? 'bg-amber-50/50 border-amber-100' : 'bg-slate-50 border-slate-100'}`}>
                      <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Equipe de hoje</p>
                      <p className="text-sm font-medium">{activeSession.staffNames}</p>
                      {isOverdue && (
                        <p className="text-[9px] text-amber-600 font-bold mt-2 uppercase tracking-tight italic">⚠️ Iniciado há mais de 24 horas</p>
                      )}
                    </div>
                    <button 
                      onClick={() => {
                        setActiveSessionPoint(point);
                        setClosingSession(activeSession);
                        setClosingPayments({ credit: 0, debit: 0, pix: 0, cash: 0 });
                        setClosingExpensesList([]);
                        setShowCloseSessionModal(true);
                      }}
                      className={`w-full py-3 text-white rounded-xl font-bold text-sm shadow-lg transition-all ${
                        isOverdue ? 'bg-amber-600 shadow-amber-200 hover:bg-amber-700' : 'bg-rose-500 shadow-rose-200 hover:bg-rose-600'
                      }`}
                    >
                      Fechar Caixa Agora
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-sm text-slate-400 italic">Ponto de venda fechado no momento.</p>
                    <button 
                      onClick={() => openSession(point)}
                      className="w-full py-3 bg-indigo-50 text-indigo-600 rounded-xl font-bold text-sm border border-indigo-100 hover:bg-indigo-100 transition-all"
                    >
                      Abrir Novo Caixa
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* MODALS */}
      {showAddPointModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200">
            <h4 className="text-2xl font-bold text-slate-800 mb-6">Criar Ponto de Venda</h4>
            <form onSubmit={handleAddPoint} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nome do Ponto</label>
                <input 
                  type="text" 
                  required
                  placeholder="Ex: Carrinho de Sorvete Praça Central"
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
                  value={newPointName}
                  onChange={e => setNewPointName(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowAddPointModal(false)} className="flex-1 px-4 py-4 border border-slate-200 rounded-2xl text-slate-500 font-bold hover:bg-slate-50">Cancelar</button>
                <button type="submit" className="flex-1 px-4 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200">Criar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showOpenSessionModal && activeSessionPoint && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl p-8 w-full max-w-2xl shadow-2xl animate-in zoom-in-95 duration-200 my-auto">
            <div className="flex justify-between items-center mb-6">
              <h4 className="text-2xl font-bold text-slate-800">Abrir Caixa: {activeSessionPoint.name}</h4>
              <button onClick={() => setShowOpenSessionModal(false)} className="text-slate-400 text-2xl">✕</button>
            </div>
            
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nome dos Funcionários</label>
                <input 
                  type="text" 
                  className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none"
                  placeholder="Ex: Pedro e Mariana"
                  value={sessionStaff}
                  onChange={e => setSessionStaff(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-4">Carregamento de Mercadorias (Carga Inicial)</label>
                
                {products.length === 0 ? (
                  <div className="p-10 border-2 border-dashed border-slate-200 rounded-3xl text-center bg-slate-50">
                    <div className="text-3xl mb-3">📦</div>
                    <p className="text-sm font-bold text-slate-600 mb-4">Seu catálogo de produtos está vazio.</p>
                    <p className="text-xs text-slate-400 mb-6">Para carregar mercadorias no ponto de venda, você precisa cadastrá-las primeiro no sistema geral.</p>
                    <button 
                      onClick={() => {
                        setShowOpenSessionModal(false);
                        setActiveTab(AppTab.PRODUCTS);
                      }}
                      className="px-6 py-3 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-indigo-100 hover:bg-indigo-700"
                    >
                      Ir para Cadastro de Produtos
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-60 overflow-y-auto pr-2">
                    {products.map(product => (
                      <div key={product.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center">
                        <div>
                          <p className="text-xs font-bold">{product.name}</p>
                          <p className="text-[10px] text-slate-400">Estoque Geral: {product.stockQuantity}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <input 
                            type="number" 
                            min="0"
                            max={product.stockQuantity}
                            className="w-16 p-2 bg-white border border-slate-200 rounded-lg text-center font-bold text-sm"
                            placeholder="0"
                            value={localQuantities[product.id] || ''}
                            onChange={e => updateLocalQty(product.id, parseInt(e.target.value) || 0)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-4 pt-6 border-t">
                <button type="button" onClick={() => setShowOpenSessionModal(false)} className="flex-1 px-4 py-4 border border-slate-200 rounded-2xl text-slate-500 font-bold">Cancelar</button>
                <button 
                  onClick={handleFinalOpen} 
                  disabled={!sessionStaff || products.length === 0 || Object.values(localQuantities).every(q => q === 0)} 
                  className="flex-1 px-4 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-lg shadow-indigo-200 disabled:opacity-30"
                >
                  Iniciar Atividade
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showCloseSessionModal && activeSessionPoint && closingSession && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl p-8 w-full max-w-5xl shadow-2xl animate-in zoom-in-95 duration-200 my-auto">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h4 className="text-2xl font-bold text-slate-800">Fechamento: {activeSessionPoint.name}</h4>
                <p className="text-sm text-slate-400 font-medium italic">Siga o passo a passo para encerramento.</p>
              </div>
              <button onClick={() => setShowCloseSessionModal(false)} className="text-slate-400 text-2xl">✕</button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Conferência de Vendas */}
              <div className="lg:col-span-1 space-y-6">
                <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <span className="w-5 h-5 bg-slate-100 rounded flex items-center justify-center text-slate-500">1</span> 
                  Itens Vendidos
                </h5>
                <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                  {closingSession.items.map((item, idx) => (
                    <div key={item.productId} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-200">
                      <div>
                        <p className="font-bold text-sm leading-tight mb-1">{item.name}</p>
                        <p className="text-[9px] text-slate-400 uppercase font-black">Levou: {item.quantityTaken}</p>
                      </div>
                      <input 
                        type="number" 
                        max={item.quantityTaken}
                        className="w-16 p-2 bg-white border border-slate-300 rounded-xl text-center font-bold text-sm outline-none"
                        value={item.quantitySold || ''}
                        onChange={e => {
                          const newItems = [...closingSession.items];
                          newItems[idx].quantitySold = Math.min(item.quantityTaken, parseInt(e.target.value) || 0);
                          setClosingSession({ ...closingSession, items: newItems });
                        }}
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Financeiro e IA */}
              <div className="lg:col-span-1 space-y-6">
                <div className="flex justify-between items-center mb-2">
                  <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-5 h-5 bg-slate-100 rounded flex items-center justify-center text-slate-500">2</span> 
                    Valores Recebidos
                  </h5>
                  <button 
                    onClick={toggleVoiceCapture}
                    disabled={isProcessingVoice}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black transition-all ${
                      isListening 
                        ? 'bg-rose-500 text-white animate-pulse' 
                        : isProcessingVoice 
                          ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                          : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100'
                    }`}
                  >
                    {isListening ? '🛑 ESCUTANDO...' : isProcessingVoice ? '⚙️ ANALISANDO...' : '✨ FALAR POR IA'}
                  </button>
                </div>
                
                <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 rounded-3xl border border-slate-200">
                  <PaymentInput label="Crédito" val={closingPayments.credit} setVal={v => setClosingPayments({...closingPayments, credit: v})} />
                  <PaymentInput label="Débito" val={closingPayments.debit} setVal={v => setClosingPayments({...closingPayments, debit: v})} />
                  <PaymentInput label="PIX" val={closingPayments.pix} setVal={v => setClosingPayments({...closingPayments, pix: v})} />
                  <PaymentInput label="Dinheiro" val={closingPayments.cash} setVal={v => setClosingPayments({...closingPayments, cash: v})} />
                </div>

                <div className="pt-4 space-y-3">
                  <div className="flex justify-between text-xs font-bold text-slate-500 px-2 uppercase">
                    <span>Faturamento Esperado:</span>
                    <span>R$ {expectedRevenue.toFixed(2)}</span>
                  </div>
                  <div className={`flex justify-between items-center p-4 rounded-2xl border font-black ${difference === 0 ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : (difference > 0 ? 'bg-blue-50 border-blue-100 text-blue-600' : 'bg-rose-50 border-rose-100 text-rose-600')}`}>
                    <span className="text-[10px] uppercase">Diferença Final:</span>
                    <span className="text-base">
                      {difference === 0 ? '✓ TUDO CERTO' : (difference > 0 ? `+ R$ ${difference.toFixed(2)}` : `- R$ ${Math.abs(difference).toFixed(2)}`)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Detalhamento de Despesas */}
              <div className="lg:col-span-1 space-y-6">
                <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <span className="w-5 h-5 bg-slate-100 rounded flex items-center justify-center text-slate-500">3</span> 
                  Despesas do Dia
                </h5>
                
                <div className="bg-rose-50/50 p-5 rounded-3xl border border-rose-100 space-y-4">
                  <div className="flex flex-col gap-2">
                    <input 
                      placeholder="Descrição (ex: Gelo)"
                      className="w-full p-3 bg-white border border-rose-200 rounded-xl outline-none text-xs font-bold"
                      value={newExpenseDesc}
                      onChange={e => setNewExpenseDesc(e.target.value)}
                    />
                    <div className="flex gap-2">
                      <input 
                        type="number"
                        placeholder="Valor R$"
                        className="flex-1 p-3 bg-white border border-rose-200 rounded-xl outline-none text-xs font-black text-rose-600"
                        value={newExpenseVal || ''}
                        onChange={e => setNewExpenseVal(parseFloat(e.target.value) || 0)}
                      />
                      <button 
                        onClick={handleAddExpense}
                        className="bg-rose-600 text-white px-4 rounded-xl text-[10px] font-black uppercase"
                      >
                        Add
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2 max-h-[150px] overflow-y-auto pr-1">
                    {closingExpensesList.map((e, i) => (
                      <div key={i} className="flex justify-between items-center bg-white p-2 rounded-xl border border-rose-100 animate-in slide-in-from-right-2">
                        <span className="text-[10px] font-bold text-slate-600 truncate flex-1">{e.description}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-black text-rose-600 whitespace-nowrap">R$ {e.value.toFixed(2)}</span>
                          <button onClick={() => handleRemoveExpense(i)} className="text-rose-300 hover:text-rose-600 text-sm p-1">✕</button>
                        </div>
                      </div>
                    ))}
                    {closingExpensesList.length === 0 && <p className="text-[9px] text-rose-300 italic text-center py-4">Nenhuma despesa lançada.</p>}
                  </div>

                  <div className="pt-3 border-t border-rose-100 flex justify-between items-center">
                    <span className="text-[10px] font-black text-rose-400 uppercase">Total Despesas:</span>
                    <span className="text-sm font-black text-rose-600">R$ {totalExpensesSum.toFixed(2)}</span>
                  </div>
                </div>

                {canViewProfit && (
                  <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-xl animate-in fade-in duration-500">
                    <p className="text-[10px] font-black text-slate-500 uppercase mb-4 tracking-widest">Lucro do Ponto</p>
                    <div className="flex justify-between items-end">
                      <span className="text-xs font-black text-indigo-400 uppercase tracking-widest">Líquido:</span>
                      <span className="text-3xl font-black italic">R$ {calculateProfit(closingSession, closingPayments, closingExpensesList).toFixed(2)}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-4 pt-8 border-t border-slate-100 mt-8">
              <button onClick={() => setShowCloseSessionModal(false)} className="flex-1 py-5 border border-slate-200 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:bg-slate-50 transition-colors">Voltar</button>
              <button 
                onClick={handleFinalClose} 
                className="flex-[2] py-5 bg-indigo-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95"
              >
                Confirmar e Encerrar Dia
              </button>
            </div>
          </div>
        </div>
      )}

      {/* HISTORY MODAL */}
      {viewingHistoryPoint && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[110] p-4 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl p-8 w-full max-w-4xl shadow-2xl animate-in zoom-in-95 duration-200 my-auto flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center mb-6 shrink-0">
              <div>
                <h4 className="text-2xl font-bold text-slate-800 tracking-tight italic">Histórico de Sessões</h4>
                <p className="text-sm text-slate-400 font-medium">Resultados consolidados: {viewingHistoryPoint.name}</p>
              </div>
              <button onClick={() => setViewingHistoryPoint(null)} className="text-slate-400 text-2xl">✕</button>
            </div>

            <div className="flex gap-2 mb-6 shrink-0 bg-slate-100 p-1 rounded-xl w-fit">
              {['all', 'day', 'week', 'month'].map(f => (
                <button key={f} onClick={() => setHistoryFilter(f as any)} className={`px-5 py-2 rounded-lg text-xs font-bold transition-all ${historyFilter === f ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>
                  {f === 'all' ? 'Tudo' : f === 'day' ? 'Hoje' : f === 'week' ? 'Semana' : 'Mês'}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto min-h-0 rounded-2xl border border-slate-100 bg-slate-50/30 divide-y divide-slate-100">
              {filteredHistory.slice().reverse().map(session => {
                const revenue = (Object.values(session.payments) as number[]).reduce((a, b) => a + b, 0);
                const profit = calculateProfit(session, session.payments, session.expenseList || []);
                
                return (
                  <div key={session.id} className="p-6 hover:bg-white transition-colors group">
                    <div className="flex flex-col lg:flex-row gap-6 justify-between lg:items-center">
                      <div>
                        <p className="text-sm font-black text-indigo-600 mb-1">{new Date(session.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                        <p className="text-xs font-medium text-slate-500">Responsável: {session.staffNames}</p>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 lg:gap-8">
                        <div>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">Vendas</p>
                          <p className="text-sm font-bold">R$ {revenue.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">Despesas</p>
                          <p className="text-sm font-bold text-rose-500">R$ {session.expenses.toFixed(2)}</p>
                        </div>
                        {canViewProfit && (
                          <div className="bg-indigo-50 px-3 py-1.5 rounded-xl border border-indigo-100 animate-in fade-in duration-300">
                            <p className="text-[10px] font-bold text-indigo-400 uppercase">Lucro Líquido</p>
                            <p className={`text-sm font-black ${profit >= 0 ? 'text-indigo-600' : 'text-rose-600'}`}>R$ {profit.toFixed(2)}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              {filteredHistory.length === 0 && <div className="p-20 text-center text-slate-400 italic font-medium">Nenhum registro encontrado.</div>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const PaymentInput = ({ label, val, setVal }: { label: string, val: number, setVal: (v: number) => void }) => (
  <div>
    <label className="block text-[9px] font-black text-slate-400 uppercase mb-1 tracking-widest">{label}</label>
    <div className="relative">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">R$</span>
      <input 
        type="number" 
        step="0.01"
        placeholder="0.00"
        className="w-full p-2.5 pl-9 bg-white border border-slate-200 rounded-xl outline-none text-xs font-black text-slate-700 focus:border-indigo-400 focus:bg-white transition-all"
        value={val || ''}
        onChange={e => setVal(parseFloat(e.target.value) || 0)}
      />
    </div>
  </div>
);

export default RemoteSales;


import React, { useState, useRef, useEffect } from 'react';
import { parseAICommand } from '../services/geminiService';
import { Product, AppTab } from '../types';

interface AICommandCenterProps {
  products: Product[];
  addProduct: (p: any) => void;
  updateStock: (id: string, qty: number) => void;
  setActiveTab: (tab: AppTab) => void;
  addContact: (c: any) => void;
}

const AICommandCenter: React.FC<AICommandCenterProps> = ({ products, addProduct, updateStock, setActiveTab, addContact }) => {
  const [command, setCommand] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([]);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'pt-BR';
      recognitionRef.current.continuous = false;
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setCommand(transcript);
        processCommand(transcript);
      };
      recognitionRef.current.onend = () => setIsListening(false);
    }
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setIsListening(true);
      recognitionRef.current?.start();
    }
  };

  const processCommand = async (text: string) => {
    if (!text.trim()) return;
    setIsProcessing(true);
    setMessages(prev => [...prev, { role: 'user', text }]);
    
    try {
      const context = { products: products.map(p => ({ id: p.id, name: p.name })) };
      const result = await parseAICommand(text, context);
      
      let aiText = "Comando processado com sucesso!";

      if (result.action === 'ADD_PRODUCT') {
        addProduct(result.data);
        aiText = `Legal! Adicionei o produto "${result.data.name}" com sucesso.`;
      } else if (result.action === 'ADD_CONTACT') {
        addContact({ ...result.data, email: '', address: '' });
        const typeLabel = result.data.type === 'customer' ? 'cliente' : result.data.type === 'supplier' ? 'fornecedor' : 'membro da equipe';
        aiText = `Entendido! Cadastrei "${result.data.name}" como ${typeLabel}.`;
      } else if (result.action === 'UPDATE_STOCK') {
        const product = products.find(p => p.id === result.data.productId || p.name.toLowerCase().includes(result.data.name?.toLowerCase() || ''));
        if (product) {
          updateStock(product.id, result.data.quantityChange);
          aiText = `Entendido. Alterei o estoque de "${product.name}" em ${result.data.quantityChange} unidades.`;
        } else {
          aiText = "Não consegui encontrar esse produto no seu estoque.";
        }
      } else if (result.action === 'ERROR') {
        aiText = result.data.message || "Desculpe, não entendi o que você quis dizer.";
      }

      setMessages(prev => [...prev, { role: 'ai', text: aiText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', text: "Houve um erro técnico. Tente novamente." }]);
    } finally {
      setIsProcessing(false);
      setCommand('');
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-white rounded-3xl shadow-xl shadow-slate-200 border border-slate-100 overflow-hidden flex flex-col h-[500px]">
        <div className="p-6 bg-indigo-600 text-white">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <span className="text-2xl">✨</span> Assistente Inteligente
          </h3>
          <p className="text-indigo-100 text-xs opacity-80">Fale ou escreva comandos para gerenciar sua empresa.</p>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/50">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center p-10 opacity-50">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-3xl mb-4 shadow-sm border border-slate-100">💡</div>
              <p className="text-sm font-medium">Tente dizer: <br/> "Adicione o cliente João telefone 9999..."<br/> ou "Tire 2 unidades de coxinha do estoque"</p>
            </div>
          )}
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm font-medium shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none' 
                  : 'bg-white text-slate-700 rounded-tl-none border border-slate-100'
              }`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex justify-start">
              <div className="bg-white p-3 rounded-2xl border flex gap-1 items-center">
                <div className="w-1.5 h-1.5 bg-indigo-300 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-white border-t border-slate-100">
          <div className="flex gap-2">
            <button 
              onClick={toggleListening}
              className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-all shadow-lg ${
                isListening ? 'bg-rose-500 text-white animate-pulse shadow-rose-200' : 'bg-slate-100 text-slate-500 hover:bg-slate-200 shadow-slate-100'
              }`}
            >
              {isListening ? '🛑' : '🎤'}
            </button>
            <input 
              type="text" 
              placeholder="Escreva um comando..."
              className="flex-1 bg-slate-50 border border-slate-200 rounded-full px-6 py-2 outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-medium"
              value={command}
              onChange={e => setCommand(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && processCommand(command)}
            />
            <button 
              onClick={() => processCommand(command)}
              disabled={isProcessing || !command.trim()}
              className="w-12 h-12 bg-indigo-600 text-white rounded-full flex items-center justify-center text-xl hover:bg-indigo-700 disabled:opacity-50 shadow-lg shadow-indigo-200 transition-all active:scale-95"
            >
              🚀
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AICommandCenter;
